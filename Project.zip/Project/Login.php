<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$database = "farhatbajwa"; // Change this to your actual database name

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]); // No hashing

    // Retrieve password from database
    $stmt = $conn->prepare("SELECT Password FROM peoples WHERE UserName = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($dbPassword);
        $stmt->fetch();

        // Directly compare passwords (⚠️ Not Secure)
        if ($password === $dbPassword) {
            $_SESSION["username"] = $username;
            echo "Login Successful! Redirecting...";
            header("refresh:2; url=dashboard.php");
            exit();
        } else {
            echo "❌ Incorrect Password!";
        }
    } else {
        echo "❌ User not found!";
    }

    $stmt->close();
}

$conn->close();
?>
